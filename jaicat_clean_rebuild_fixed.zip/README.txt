Usage:
1. Extract this zip to the parent directory ABOVE your 'jaicat_project' folder.
2. Run 'clean_rebuild_push_fixed.bat'.
3. It will create 'jaicat_clean', reinit Git + LFS, and force-push a clean version to GitHub.

You must have Git, Git LFS, and Java installed.