Usage:
1. Extract this zip inside your broken repo folder.
2. Run 'clean_rebuild_push.bat'.
3. Wait while it clones into 'jaicat_clean', reinitializes git and pushes a clean history with yolov7.weights tracked by LFS.

You must have Git, Git LFS, and an active internet connection.