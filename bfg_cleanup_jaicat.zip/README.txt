Please download 'bfg-1.14.0.jar' from:
https://repo1.maven.org/maven2/com/madgag/bfg/1.14.0/bfg-1.14.0.jar
and place it next to bfg_cleanup.bat before running.