Usage:
1. Place this zip in the folder that contains 'jaicat_project'
2. Extract and run 'clean_rebuild_push_secure.bat'
3. Only 'jaicat_project' will be copied and pushed — nothing else.